function dragOver(e){
	e.preventDefault();
}
	
function drop(e){
	e.preventDefault();
	let data=e.dataTransfer.getData("data");
	let word=document.getElementById(data).innerHTML;
	e.target.innerHTML = word;	
}

function drag(e){
	e.dataTransfer.setData("data", e.target.id);
}

function submitQuote(){
	let myquote=document.getElementById("my-quote").innerHTML;
	alert(myquote);
}